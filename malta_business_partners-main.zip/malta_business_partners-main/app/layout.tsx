// app/layout.tsx
import type { Metadata } from "next";
import Script from "next/script";
import ClientBoot from "@/components/ClientBoot";
import FloatingWhatsApp from "@/components/FloatingWhatsApp";

export const metadata: Metadata = {
  title: "XLW Advisory Malta",
  description:
    "Accounting, tax, audit, finance and digital services — delivered by a team that keeps things clear, compliant and growth-ready.",
};

export const viewport = {
  width: "device-width",
  initialScale: 1,
  minimumScale: 1,
  maximumScale: 1,
  viewportFit: "cover" as const,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-bs-theme="light" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="" />
        <link rel="stylesheet" href="/assets/css2" />

        <link rel="stylesheet" href="/assets/swiper-bundle.min.css" />
        <link rel="stylesheet" href="/assets/aos.css" />
        <link rel="stylesheet" href="/assets/around-icons.min.css" />
        <link rel="stylesheet" href="/assets/theme.min.css" />

        <Script src="/assets/theme-switcher.js" strategy="beforeInteractive" />
      </head>

      <body data-aos-easing="ease" data-aos-duration="400" data-aos-delay="0">
        {children}
        <FloatingWhatsApp
        phone={process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "35699520938"}
        message="Hi! I’d like to book a free consultation."
      />

        {/* Vendor libs */}
        <Script src="/assets/jarallax.min.js" strategy="afterInteractive" />
        <Script src="/assets/swiper-bundle.min.js" strategy="afterInteractive" />
        <Script src="/assets/aos.js" strategy="afterInteractive" />

        {/* ✅ init Bootstrap + AOS safely (no theme.min.js) */}
        <ClientBoot />

        {/* 🚫 keep this disabled */}
        {/* <Script src="/assets/theme.min.js" strategy="afterInteractive" /> */}
      </body>
    </html>
  );
}