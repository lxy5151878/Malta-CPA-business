/* eslint-disable @next/next/no-img-element */
import type { SiteCopy } from "@/lib/siteCopy";

export default function Hero({ copy }: { copy: SiteCopy }) {
  const hero = copy.hero;

  return (
    <section className="overflow-hidden">
      <div className="container pt-2 pt-sm-4 pb-3 pb-md-4 mt-5">
        <div className="row align-items-center pt-4 pb-3 pt-md-5 pb-md-4 mt-md-2">
          {/* Right: image */}
          <div className="col-lg-7 order-lg-2 d-flex justify-content-center justify-content-lg-end mb-4 mb-md-5 mb-lg-0 pb-3 pb-md-0">
            {/* ✅ Mobile/tablet: narrower */}
            <div
              className="d-lg-none mx-auto"
              style={{ width: "95%", maxWidth: 520 }}
              aria-hidden="true"
            >
              <img
                src={hero.backgroundImage}
                alt="Hero visual"
                className="img-fluid rounded-1 shadow-sm"
                style={{ width: "100%", height: "auto" }}
              />
            </div>

            {/* ✅ Desktop (lg+): keep original size */}
            <div
              className="d-none d-lg-block"
              style={{ width: "100%", maxWidth: 667 }}
              aria-hidden="true"
            >
              <img
                src={hero.backgroundImage}
                alt="Hero visual"
                className="img-fluid rounded-1 shadow-sm"
                style={{ width: "100%", height: "auto" }}
              />
            </div>
          </div>

          {/* Left: text + CTAs unchanged */}
          <div className="col-lg-5 order-lg-1">
            <h1 className="display-3 text-center text-lg-start pb-sm-2 pb-md-3">
              {hero.title}
            </h1>

            <p
              className="fs-lg text-center text-lg-start pb-xl-2 mx-auto mx-lg-0 mb-4 mb-lg-5"
              style={{ maxWidth: 420 }}
            >
              {hero.subtitle}
            </p>

            <div className="mx-auto mx-lg-0" style={{ maxWidth: 420 }}>
              <div className="d-flex flex-column flex-sm-row gap-3">
                <a className="btn btn-primary btn-lg" href={hero.primaryCta.href}>
                  <i className="ai-message fs-xl me-2 ms-n1" />
                  {hero.primaryCta.label}
                </a>

                <a
                  className="btn btn-outline-primary btn-lg d-flex align-items-center justify-content-center"
                  href={hero.phone.href}
                >
                  <i className="ai-phone fs-xl me-2" />
                  {hero.phone.label}
                </a>
              </div>

              <ul className="list-unstyled d-flex flex-column flex-sm-row gap-2 gap-sm-4 mb-0 pt-4 pt-lg-4">
                {hero.bullets.map((b) => (
                  <li className="d-flex align-items-start" key={b}>
                    <i className="ai-check-alt text-primary fs-4 mt-n1 me-2" />
                    {b}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}