import type { SiteCopy } from "@/lib/siteCopy";

function SocialIcon({ kind }: { kind: string }) {
  // template uses around-icons (ai-*)
  return <i className={`ai-${kind}`} />;
}

export default function Footer({ copy }: { copy: SiteCopy }) {
  const f = copy.footer;

  return (
    <footer className="footer bg-dark pb-3 pt-sm-3 py-md-4 py-lg-5" data-bs-theme="dark" id={f.id}>
      <div className="container pb-4 pt-5">
        <div className="d-md-flex align-items-center justify-content-between pb-1 pb-md-0 mb-4 mb-md-5">
          <nav className="nav justify-content-center justify-content-md-start pb-sm-2 pb-md-0 mb-4 mb-md-0 ms-md-n3">
            {f.nav.map((x) => (
              <a key={x.label} className="nav-link py-1 px-0 mx-3" href={x.href}>
                {x.label}
              </a>
            ))}
          </nav>

          <div className="d-flex justify-content-center justify-content-md-start me-md-n2">
            {f.socials.map((s) => (
              <a
                key={s.kind}
                className={`btn btn-icon btn-sm btn-secondary btn-${s.kind} rounded-circle mx-2`}
                href={s.href}
                aria-label={s.label}
              >
                <SocialIcon kind={s.kind} />
              </a>
            ))}
          </div>
        </div>

        <div className="nav d-block d-md-flex align-items-center justify-content-between text-center text-md-start">
          <a className="nav-link d-inline-block text-body-secondary fs-sm text-decoration-none order-md-2 py-1 px-0 mb-3 mb-md-0" href={f.privacy.href}>
            {f.privacy.label}
          </a>

          <p className="fs-sm order-md-1 mb-0">
            <span className="text-body-secondary">{f.copyright.prefix}</span>
            <a className="nav-link d-inline fw-normal p-0 ms-1" href={f.copyright.linkHref}>
              {f.copyright.linkLabel}
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
}